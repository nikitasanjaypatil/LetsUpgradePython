

message = "hey this is sai,i am in mumbai"

capitalized_message = " ".join([   
    
    word.capitalize()
    for word in message.split(" ")
])

print(capitalized_message)
