

test_list = [1,5,6,4,1,2,3,5]
sub_list = [1,1,5]

flag = 0
if(all(x in test_list for x in sub_list)):
    flag = 1

if (flag) :
    print ("It's a Match")
else :
    print ("It's Gone")

