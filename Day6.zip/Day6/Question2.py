

import math

class Cone:
    def __init__(self,r,h):
        self.r = r
        self.h = h

    def volume(self):
        volume = (math.pi * (self.r**2) * (self.h/3))
        print("Volume = ",round(volume,2))

    def surfaceArea(self):
        surfacearea = math.pi*self.r*(self.r+math.sqrt((self.h**2)+(self.r**2)))
        print("Surface Area = ",round(surfacearea,2))

radius = float(input("Enter radius : "))
height = float(input("Enter height : "))

obj = Cone(radius,height)

obj.volume()
obj.surfaceArea()
