

class BankAccount: 

    def __init__(self): 
        self.ownerName = "Nikeeta"
        self.Balance = 3000
        
    def deposit(self): 
        amt=int(input("\nEnter amount to be deposited : ")) 
        self.Balance += amt 
        print("Balance after amount deposited :",self.Balance) 
  
    def withdraw(self): 
        amt = int(input("\nEnter amount to be Withdrawn : ")) 
        if self.Balance >= amt: 
            self.Balance -= amt 
            print("Balance after amount withdrawn :", self.Balance) 
        else: 
            print("\nInsufficient Balance in Account") 

obj = BankAccount()
print("\nAccount Holder Name :",obj.ownerName)
print("\nInitial Account Balance :",obj.Balance)
obj.deposit();
obj.withdraw();
